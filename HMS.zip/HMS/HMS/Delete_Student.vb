﻿Public Class Delete_Student

End Class
﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Hostel_Fees_Details
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PanelHostelFees = New System.Windows.Forms.Panel()
        Me.TXTtotalfees = New System.Windows.Forms.TextBox()
        Me.lblTotalfees = New System.Windows.Forms.Label()
        Me.cmbRoomOcupancy = New System.Windows.Forms.ComboBox()
        Me.lblpincode = New System.Windows.Forms.Label()
        Me.cmbRoomType = New System.Windows.Forms.ComboBox()
        Me.txtTransactionID = New System.Windows.Forms.TextBox()
        Me.lblTransactionID = New System.Windows.Forms.Label()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnBACK = New System.Windows.Forms.Button()
        Me.btnPayNow = New System.Windows.Forms.Button()
        Me.lblDetails = New System.Windows.Forms.Label()
        Me.txtDetails = New System.Windows.Forms.TextBox()
        Me.cmbPayMode = New System.Windows.Forms.ComboBox()
        Me.lblPaymentMode = New System.Windows.Forms.Label()
        Me.txtPanaltyAmount = New System.Windows.Forms.TextBox()
        Me.lblPanaltyAmount = New System.Windows.Forms.Label()
        Me.txtMobileno = New System.Windows.Forms.TextBox()
        Me.lblmobileno = New System.Windows.Forms.Label()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.lblJoinDate = New System.Windows.Forms.Label()
        Me.txtEmailid = New System.Windows.Forms.TextBox()
        Me.lblStdEmailId = New System.Windows.Forms.Label()
        Me.lblRoomType = New System.Windows.Forms.Label()
        Me.cmbFirstName = New System.Windows.Forms.ComboBox()
        Me.txtRegisterID = New System.Windows.Forms.TextBox()
        Me.lblRegisterID = New System.Windows.Forms.Label()
        Me.txtLname = New System.Windows.Forms.TextBox()
        Me.lblLname = New System.Windows.Forms.Label()
        Me.lblDept = New System.Windows.Forms.Label()
        Me.ComboBoxDept = New System.Windows.Forms.ComboBox()
        Me.lblFname = New System.Windows.Forms.Label()
        Me.lblHostelFeesDetails = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.PanelHostelFees.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PanelHostelFees
        '
        Me.PanelHostelFees.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.PanelHostelFees.BackColor = System.Drawing.Color.Transparent
        Me.PanelHostelFees.Controls.Add(Me.DataGridView1)
        Me.PanelHostelFees.Controls.Add(Me.TXTtotalfees)
        Me.PanelHostelFees.Controls.Add(Me.lblTotalfees)
        Me.PanelHostelFees.Controls.Add(Me.cmbRoomOcupancy)
        Me.PanelHostelFees.Controls.Add(Me.lblpincode)
        Me.PanelHostelFees.Controls.Add(Me.cmbRoomType)
        Me.PanelHostelFees.Controls.Add(Me.txtTransactionID)
        Me.PanelHostelFees.Controls.Add(Me.lblTransactionID)
        Me.PanelHostelFees.Controls.Add(Me.btnReset)
        Me.PanelHostelFees.Controls.Add(Me.btnBACK)
        Me.PanelHostelFees.Controls.Add(Me.btnPayNow)
        Me.PanelHostelFees.Controls.Add(Me.lblDetails)
        Me.PanelHostelFees.Controls.Add(Me.txtDetails)
        Me.PanelHostelFees.Controls.Add(Me.cmbPayMode)
        Me.PanelHostelFees.Controls.Add(Me.lblPaymentMode)
        Me.PanelHostelFees.Controls.Add(Me.txtPanaltyAmount)
        Me.PanelHostelFees.Controls.Add(Me.lblPanaltyAmount)
        Me.PanelHostelFees.Controls.Add(Me.txtMobileno)
        Me.PanelHostelFees.Controls.Add(Me.lblmobileno)
        Me.PanelHostelFees.Controls.Add(Me.DateTimePicker1)
        Me.PanelHostelFees.Controls.Add(Me.lblJoinDate)
        Me.PanelHostelFees.Controls.Add(Me.txtEmailid)
        Me.PanelHostelFees.Controls.Add(Me.lblStdEmailId)
        Me.PanelHostelFees.Controls.Add(Me.lblRoomType)
        Me.PanelHostelFees.Controls.Add(Me.cmbFirstName)
        Me.PanelHostelFees.Controls.Add(Me.txtRegisterID)
        Me.PanelHostelFees.Controls.Add(Me.lblRegisterID)
        Me.PanelHostelFees.Controls.Add(Me.txtLname)
        Me.PanelHostelFees.Controls.Add(Me.lblLname)
        Me.PanelHostelFees.Controls.Add(Me.lblDept)
        Me.PanelHostelFees.Controls.Add(Me.ComboBoxDept)
        Me.PanelHostelFees.Controls.Add(Me.lblFname)
        Me.PanelHostelFees.Controls.Add(Me.lblHostelFeesDetails)
        Me.PanelHostelFees.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PanelHostelFees.ForeColor = System.Drawing.Color.White
        Me.PanelHostelFees.Location = New System.Drawing.Point(12, 12)
        Me.PanelHostelFees.Name = "PanelHostelFees"
        Me.PanelHostelFees.Size = New System.Drawing.Size(833, 626)
        Me.PanelHostelFees.TabIndex = 0
        '
        'TXTtotalfees
        '
        Me.TXTtotalfees.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.TXTtotalfees.Enabled = False
        Me.TXTtotalfees.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXTtotalfees.ForeColor = System.Drawing.Color.Black
        Me.TXTtotalfees.Location = New System.Drawing.Point(615, 243)
        Me.TXTtotalfees.Name = "TXTtotalfees"
        Me.TXTtotalfees.Size = New System.Drawing.Size(206, 22)
        Me.TXTtotalfees.TabIndex = 80
        '
        'lblTotalfees
        '
        Me.lblTotalfees.AutoSize = True
        Me.lblTotalfees.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblTotalfees.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalfees.ForeColor = System.Drawing.Color.White
        Me.lblTotalfees.Location = New System.Drawing.Point(464, 246)
        Me.lblTotalfees.Name = "lblTotalfees"
        Me.lblTotalfees.Size = New System.Drawing.Size(100, 16)
        Me.lblTotalfees.TabIndex = 79
        Me.lblTotalfees.Text = "TOTAL FEES"
        '
        'cmbRoomOcupancy
        '
        Me.cmbRoomOcupancy.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.cmbRoomOcupancy.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.cmbRoomOcupancy.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbRoomOcupancy.ForeColor = System.Drawing.Color.Black
        Me.cmbRoomOcupancy.FormattingEnabled = True
        Me.cmbRoomOcupancy.Items.AddRange(New Object() {"SOLO-1", "DUO-2", "TRIPLE-3", "QUATRA-4"})
        Me.cmbRoomOcupancy.Location = New System.Drawing.Point(615, 204)
        Me.cmbRoomOcupancy.Name = "cmbRoomOcupancy"
        Me.cmbRoomOcupancy.Size = New System.Drawing.Size(206, 24)
        Me.cmbRoomOcupancy.TabIndex = 78
        '
        'lblpincode
        '
        Me.lblpincode.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblpincode.AutoSize = True
        Me.lblpincode.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblpincode.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpincode.ForeColor = System.Drawing.Color.White
        Me.lblpincode.Location = New System.Drawing.Point(446, 207)
        Me.lblpincode.Name = "lblpincode"
        Me.lblpincode.Size = New System.Drawing.Size(150, 16)
        Me.lblpincode.TabIndex = 77
        Me.lblpincode.Text = "ROOM OCCUPANCY"
        '
        'cmbRoomType
        '
        Me.cmbRoomType.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.cmbRoomType.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.cmbRoomType.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbRoomType.ForeColor = System.Drawing.Color.Black
        Me.cmbRoomType.FormattingEnabled = True
        Me.cmbRoomType.Items.AddRange(New Object() {"AC", "NON-AC"})
        Me.cmbRoomType.Location = New System.Drawing.Point(225, 199)
        Me.cmbRoomType.Name = "cmbRoomType"
        Me.cmbRoomType.Size = New System.Drawing.Size(207, 24)
        Me.cmbRoomType.TabIndex = 76
        Me.cmbRoomType.Text = "NON-AC"
        '
        'txtTransactionID
        '
        Me.txtTransactionID.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtTransactionID.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtTransactionID.Enabled = False
        Me.txtTransactionID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTransactionID.ForeColor = System.Drawing.Color.Black
        Me.txtTransactionID.Location = New System.Drawing.Point(225, 321)
        Me.txtTransactionID.Name = "txtTransactionID"
        Me.txtTransactionID.Size = New System.Drawing.Size(207, 22)
        Me.txtTransactionID.TabIndex = 74
        '
        'lblTransactionID
        '
        Me.lblTransactionID.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblTransactionID.AutoSize = True
        Me.lblTransactionID.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblTransactionID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTransactionID.ForeColor = System.Drawing.Color.Transparent
        Me.lblTransactionID.Location = New System.Drawing.Point(43, 327)
        Me.lblTransactionID.Name = "lblTransactionID"
        Me.lblTransactionID.Size = New System.Drawing.Size(135, 16)
        Me.lblTransactionID.TabIndex = 75
        Me.lblTransactionID.Text = "TRANSACTION ID"
        '
        'btnReset
        '
        Me.btnReset.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnReset.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnReset.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReset.ForeColor = System.Drawing.Color.Black
        Me.btnReset.Location = New System.Drawing.Point(355, 560)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(160, 47)
        Me.btnReset.TabIndex = 73
        Me.btnReset.Text = "RESET"
        Me.btnReset.UseVisualStyleBackColor = False
        '
        'btnBACK
        '
        Me.btnBACK.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnBACK.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnBACK.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBACK.ForeColor = System.Drawing.Color.Black
        Me.btnBACK.Location = New System.Drawing.Point(607, 560)
        Me.btnBACK.Name = "btnBACK"
        Me.btnBACK.Size = New System.Drawing.Size(160, 47)
        Me.btnBACK.TabIndex = 71
        Me.btnBACK.Text = "BACK"
        Me.btnBACK.UseVisualStyleBackColor = False
        '
        'btnPayNow
        '
        Me.btnPayNow.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnPayNow.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnPayNow.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPayNow.ForeColor = System.Drawing.Color.Black
        Me.btnPayNow.Location = New System.Drawing.Point(102, 560)
        Me.btnPayNow.Name = "btnPayNow"
        Me.btnPayNow.Size = New System.Drawing.Size(160, 47)
        Me.btnPayNow.TabIndex = 70
        Me.btnPayNow.Text = "PAY NOW"
        Me.btnPayNow.UseVisualStyleBackColor = False
        '
        'lblDetails
        '
        Me.lblDetails.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblDetails.AutoSize = True
        Me.lblDetails.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblDetails.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDetails.ForeColor = System.Drawing.Color.White
        Me.lblDetails.Location = New System.Drawing.Point(498, 302)
        Me.lblDetails.Name = "lblDetails"
        Me.lblDetails.Size = New System.Drawing.Size(71, 16)
        Me.lblDetails.TabIndex = 69
        Me.lblDetails.Text = "DETAILS"
        '
        'txtDetails
        '
        Me.txtDetails.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtDetails.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDetails.Location = New System.Drawing.Point(607, 286)
        Me.txtDetails.Multiline = True
        Me.txtDetails.Name = "txtDetails"
        Me.txtDetails.Size = New System.Drawing.Size(214, 57)
        Me.txtDetails.TabIndex = 68
        Me.txtDetails.Text = "PAY HOSTEL FEES"
        '
        'cmbPayMode
        '
        Me.cmbPayMode.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.cmbPayMode.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.cmbPayMode.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbPayMode.ForeColor = System.Drawing.Color.Black
        Me.cmbPayMode.FormattingEnabled = True
        Me.cmbPayMode.Items.AddRange(New Object() {"CASH", "GPAY", "PAYTM", "UPI", "BANK TRANSFER", "CHECK", "RTGS", "OTHER"})
        Me.cmbPayMode.Location = New System.Drawing.Point(223, 286)
        Me.cmbPayMode.Name = "cmbPayMode"
        Me.cmbPayMode.Size = New System.Drawing.Size(207, 24)
        Me.cmbPayMode.TabIndex = 67
        '
        'lblPaymentMode
        '
        Me.lblPaymentMode.AutoSize = True
        Me.lblPaymentMode.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblPaymentMode.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPaymentMode.ForeColor = System.Drawing.Color.Transparent
        Me.lblPaymentMode.Location = New System.Drawing.Point(60, 284)
        Me.lblPaymentMode.Name = "lblPaymentMode"
        Me.lblPaymentMode.Size = New System.Drawing.Size(129, 16)
        Me.lblPaymentMode.TabIndex = 66
        Me.lblPaymentMode.Text = "PAYMENT MODE"
        '
        'txtPanaltyAmount
        '
        Me.txtPanaltyAmount.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtPanaltyAmount.Enabled = False
        Me.txtPanaltyAmount.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPanaltyAmount.ForeColor = System.Drawing.Color.Black
        Me.txtPanaltyAmount.Location = New System.Drawing.Point(222, 240)
        Me.txtPanaltyAmount.Name = "txtPanaltyAmount"
        Me.txtPanaltyAmount.Size = New System.Drawing.Size(207, 22)
        Me.txtPanaltyAmount.TabIndex = 65
        '
        'lblPanaltyAmount
        '
        Me.lblPanaltyAmount.AutoSize = True
        Me.lblPanaltyAmount.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblPanaltyAmount.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPanaltyAmount.ForeColor = System.Drawing.Color.Transparent
        Me.lblPanaltyAmount.Location = New System.Drawing.Point(40, 246)
        Me.lblPanaltyAmount.Name = "lblPanaltyAmount"
        Me.lblPanaltyAmount.Size = New System.Drawing.Size(137, 16)
        Me.lblPanaltyAmount.TabIndex = 64
        Me.lblPanaltyAmount.Text = "HOSTEL AMOUNT"
        '
        'txtMobileno
        '
        Me.txtMobileno.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtMobileno.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtMobileno.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMobileno.ForeColor = System.Drawing.Color.Black
        Me.txtMobileno.Location = New System.Drawing.Point(615, 119)
        Me.txtMobileno.Name = "txtMobileno"
        Me.txtMobileno.Size = New System.Drawing.Size(214, 22)
        Me.txtMobileno.TabIndex = 62
        '
        'lblmobileno
        '
        Me.lblmobileno.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblmobileno.AutoSize = True
        Me.lblmobileno.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblmobileno.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmobileno.ForeColor = System.Drawing.Color.White
        Me.lblmobileno.Location = New System.Drawing.Point(464, 125)
        Me.lblmobileno.Name = "lblmobileno"
        Me.lblmobileno.Size = New System.Drawing.Size(132, 16)
        Me.lblmobileno.TabIndex = 63
        Me.lblmobileno.Text = "MOBILE NUMBER"
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.DateTimePicker1.Enabled = False
        Me.DateTimePicker1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateTimePicker1.Location = New System.Drawing.Point(607, 55)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(200, 22)
        Me.DateTimePicker1.TabIndex = 59
        '
        'lblJoinDate
        '
        Me.lblJoinDate.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblJoinDate.AutoSize = True
        Me.lblJoinDate.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblJoinDate.Enabled = False
        Me.lblJoinDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblJoinDate.ForeColor = System.Drawing.Color.White
        Me.lblJoinDate.Location = New System.Drawing.Point(529, 61)
        Me.lblJoinDate.Name = "lblJoinDate"
        Me.lblJoinDate.Size = New System.Drawing.Size(49, 16)
        Me.lblJoinDate.TabIndex = 61
        Me.lblJoinDate.Text = "DATE"
        '
        'txtEmailid
        '
        Me.txtEmailid.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtEmailid.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtEmailid.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmailid.ForeColor = System.Drawing.Color.Black
        Me.txtEmailid.Location = New System.Drawing.Point(614, 161)
        Me.txtEmailid.Name = "txtEmailid"
        Me.txtEmailid.Size = New System.Drawing.Size(214, 22)
        Me.txtEmailid.TabIndex = 57
        '
        'lblStdEmailId
        '
        Me.lblStdEmailId.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblStdEmailId.AutoSize = True
        Me.lblStdEmailId.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblStdEmailId.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStdEmailId.ForeColor = System.Drawing.Color.White
        Me.lblStdEmailId.Location = New System.Drawing.Point(506, 167)
        Me.lblStdEmailId.Name = "lblStdEmailId"
        Me.lblStdEmailId.Size = New System.Drawing.Size(71, 16)
        Me.lblStdEmailId.TabIndex = 58
        Me.lblStdEmailId.Text = "EMAIL ID"
        '
        'lblRoomType
        '
        Me.lblRoomType.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblRoomType.AutoSize = True
        Me.lblRoomType.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblRoomType.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRoomType.ForeColor = System.Drawing.Color.Transparent
        Me.lblRoomType.Location = New System.Drawing.Point(58, 202)
        Me.lblRoomType.Name = "lblRoomType"
        Me.lblRoomType.Size = New System.Drawing.Size(97, 16)
        Me.lblRoomType.TabIndex = 52
        Me.lblRoomType.Text = "ROOM TYPE"
        '
        'cmbFirstName
        '
        Me.cmbFirstName.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.cmbFirstName.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.cmbFirstName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbFirstName.ForeColor = System.Drawing.Color.Black
        Me.cmbFirstName.FormattingEnabled = True
        Me.cmbFirstName.Items.AddRange(New Object() {"ARTS", "COMMERCE", "SCIENCE", "IT", "AGRICULTURE", "MANAGEMENT", "PHARMACY", "ITI", "INDUSTRIAL", "OTHER"})
        Me.cmbFirstName.Location = New System.Drawing.Point(222, 155)
        Me.cmbFirstName.Name = "cmbFirstName"
        Me.cmbFirstName.Size = New System.Drawing.Size(207, 24)
        Me.cmbFirstName.TabIndex = 50
        '
        'txtRegisterID
        '
        Me.txtRegisterID.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtRegisterID.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtRegisterID.Enabled = False
        Me.txtRegisterID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRegisterID.ForeColor = System.Drawing.Color.Black
        Me.txtRegisterID.Location = New System.Drawing.Point(222, 69)
        Me.txtRegisterID.Name = "txtRegisterID"
        Me.txtRegisterID.Size = New System.Drawing.Size(207, 22)
        Me.txtRegisterID.TabIndex = 43
        '
        'lblRegisterID
        '
        Me.lblRegisterID.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblRegisterID.AutoSize = True
        Me.lblRegisterID.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblRegisterID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRegisterID.ForeColor = System.Drawing.Color.Transparent
        Me.lblRegisterID.Location = New System.Drawing.Point(40, 75)
        Me.lblRegisterID.Name = "lblRegisterID"
        Me.lblRegisterID.Size = New System.Drawing.Size(140, 16)
        Me.lblRegisterID.TabIndex = 49
        Me.lblRegisterID.Text = "REGISTRATION ID"
        '
        'txtLname
        '
        Me.txtLname.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtLname.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtLname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLname.ForeColor = System.Drawing.Color.Black
        Me.txtLname.Location = New System.Drawing.Point(614, 83)
        Me.txtLname.Name = "txtLname"
        Me.txtLname.Size = New System.Drawing.Size(207, 22)
        Me.txtLname.TabIndex = 47
        '
        'lblLname
        '
        Me.lblLname.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblLname.AutoSize = True
        Me.lblLname.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblLname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLname.ForeColor = System.Drawing.Color.White
        Me.lblLname.Location = New System.Drawing.Point(476, 89)
        Me.lblLname.Name = "lblLname"
        Me.lblLname.Size = New System.Drawing.Size(93, 16)
        Me.lblLname.TabIndex = 48
        Me.lblLname.Text = "LAST NAME"
        '
        'lblDept
        '
        Me.lblDept.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblDept.AutoSize = True
        Me.lblDept.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblDept.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDept.ForeColor = System.Drawing.Color.Transparent
        Me.lblDept.Location = New System.Drawing.Point(70, 113)
        Me.lblDept.Name = "lblDept"
        Me.lblDept.Size = New System.Drawing.Size(113, 16)
        Me.lblDept.TabIndex = 44
        Me.lblDept.Text = "DEPARTMENT"
        '
        'ComboBoxDept
        '
        Me.ComboBoxDept.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.ComboBoxDept.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ComboBoxDept.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBoxDept.ForeColor = System.Drawing.Color.Black
        Me.ComboBoxDept.FormattingEnabled = True
        Me.ComboBoxDept.Items.AddRange(New Object() {"ARTS", "COMMERCE", "SCIENCE", "IT", "AGRICULTURE", "MANAGEMENT", "PHARMACY", "ITI", "INDUSTRIAL", "OTHER"})
        Me.ComboBoxDept.Location = New System.Drawing.Point(222, 107)
        Me.ComboBoxDept.Name = "ComboBoxDept"
        Me.ComboBoxDept.Size = New System.Drawing.Size(207, 24)
        Me.ComboBoxDept.TabIndex = 45
        '
        'lblFname
        '
        Me.lblFname.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblFname.AutoSize = True
        Me.lblFname.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblFname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFname.ForeColor = System.Drawing.Color.Transparent
        Me.lblFname.Location = New System.Drawing.Point(84, 158)
        Me.lblFname.Name = "lblFname"
        Me.lblFname.Size = New System.Drawing.Size(99, 16)
        Me.lblFname.TabIndex = 46
        Me.lblFname.Text = "FIRST NAME"
        '
        'lblHostelFeesDetails
        '
        Me.lblHostelFeesDetails.AutoSize = True
        Me.lblHostelFeesDetails.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblHostelFeesDetails.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHostelFeesDetails.Location = New System.Drawing.Point(292, 13)
        Me.lblHostelFeesDetails.Name = "lblHostelFeesDetails"
        Me.lblHostelFeesDetails.Size = New System.Drawing.Size(269, 25)
        Me.lblHostelFeesDetails.TabIndex = 0
        Me.lblHostelFeesDetails.Text = "HOSTEL FEES DETAILS"
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(46, 379)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(761, 159)
        Me.DataGridView1.TabIndex = 81
        '
        'Hostel_Fees_Details
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.BackgroundImage = Global.HMS.My.Resources.Resources.Hostel_Wallpaper_Background
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(875, 650)
        Me.Controls.Add(Me.PanelHostelFees)
        Me.Name = "Hostel_Fees_Details"
        Me.Text = "Hostel_Fees_Details"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.PanelHostelFees.ResumeLayout(False)
        Me.PanelHostelFees.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PanelHostelFees As System.Windows.Forms.Panel
    Friend WithEvents lblHostelFeesDetails As System.Windows.Forms.Label
    Friend WithEvents cmbFirstName As System.Windows.Forms.ComboBox
    Friend WithEvents txtRegisterID As System.Windows.Forms.TextBox
    Friend WithEvents lblRegisterID As System.Windows.Forms.Label
    Friend WithEvents txtLname As System.Windows.Forms.TextBox
    Friend WithEvents lblLname As System.Windows.Forms.Label
    Friend WithEvents lblDept As System.Windows.Forms.Label
    Friend WithEvents ComboBoxDept As System.Windows.Forms.ComboBox
    Friend WithEvents lblFname As System.Windows.Forms.Label
    Friend WithEvents lblRoomType As System.Windows.Forms.Label
    Friend WithEvents txtMobileno As System.Windows.Forms.TextBox
    Friend WithEvents lblmobileno As System.Windows.Forms.Label
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblJoinDate As System.Windows.Forms.Label
    Friend WithEvents txtEmailid As System.Windows.Forms.TextBox
    Friend WithEvents lblStdEmailId As System.Windows.Forms.Label
    Friend WithEvents lblPaymentMode As System.Windows.Forms.Label
    Friend WithEvents txtPanaltyAmount As System.Windows.Forms.TextBox
    Friend WithEvents lblPanaltyAmount As System.Windows.Forms.Label
    Friend WithEvents cmbPayMode As System.Windows.Forms.ComboBox
    Friend WithEvents lblDetails As System.Windows.Forms.Label
    Friend WithEvents txtDetails As System.Windows.Forms.TextBox
    Friend WithEvents btnReset As System.Windows.Forms.Button
    Friend WithEvents btnBACK As System.Windows.Forms.Button
    Friend WithEvents btnPayNow As System.Windows.Forms.Button
    Friend WithEvents txtTransactionID As System.Windows.Forms.TextBox
    Friend WithEvents lblTransactionID As System.Windows.Forms.Label
    Friend WithEvents cmbRoomType As System.Windows.Forms.ComboBox
    Friend WithEvents TXTtotalfees As System.Windows.Forms.TextBox
    Friend WithEvents lblTotalfees As System.Windows.Forms.Label
    Friend WithEvents cmbRoomOcupancy As System.Windows.Forms.ComboBox
    Friend WithEvents lblpincode As System.Windows.Forms.Label
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
End Class

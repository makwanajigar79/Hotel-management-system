﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AddRooms
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txtTotalfees = New System.Windows.Forms.TextBox()
        Me.lblTotalfees = New System.Windows.Forms.Label()
        Me.btnREset = New System.Windows.Forms.Button()
        Me.DataGridViewAddRoom = New System.Windows.Forms.DataGridView()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.txtDetails = New System.Windows.Forms.TextBox()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.lblRoomDetails = New System.Windows.Forms.Label()
        Me.lblFees = New System.Windows.Forms.Label()
        Me.cmbRoomOcupancy = New System.Windows.Forms.ComboBox()
        Me.cmbRoomType = New System.Windows.Forms.ComboBox()
        Me.cmbFirstName = New System.Windows.Forms.ComboBox()
        Me.txtMobileno = New System.Windows.Forms.TextBox()
        Me.lblmobileno = New System.Windows.Forms.Label()
        Me.lblpincode = New System.Windows.Forms.Label()
        Me.txtfees = New System.Windows.Forms.TextBox()
        Me.lblRoomType = New System.Windows.Forms.Label()
        Me.DateTimePickerOUT = New System.Windows.Forms.DateTimePicker()
        Me.lblCheckOut = New System.Windows.Forms.Label()
        Me.DateTimePickerIN = New System.Windows.Forms.DateTimePicker()
        Me.lblChechIN = New System.Windows.Forms.Label()
        Me.txtRegisterID = New System.Windows.Forms.TextBox()
        Me.lblRegisterID = New System.Windows.Forms.Label()
        Me.txtRoomID = New System.Windows.Forms.TextBox()
        Me.lblRoomId = New System.Windows.Forms.Label()
        Me.txtEmailid = New System.Windows.Forms.TextBox()
        Me.lblStdEmailId = New System.Windows.Forms.Label()
        Me.txtRoomBlock = New System.Windows.Forms.TextBox()
        Me.lblRoomBlock = New System.Windows.Forms.Label()
        Me.lblFname = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        CType(Me.DataGridViewAddRoom, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel1.Controls.Add(Me.txtTotalfees)
        Me.Panel1.Controls.Add(Me.lblTotalfees)
        Me.Panel1.Controls.Add(Me.btnREset)
        Me.Panel1.Controls.Add(Me.DataGridViewAddRoom)
        Me.Panel1.Controls.Add(Me.btnBack)
        Me.Panel1.Controls.Add(Me.txtDetails)
        Me.Panel1.Controls.Add(Me.btnAdd)
        Me.Panel1.Controls.Add(Me.lblRoomDetails)
        Me.Panel1.Controls.Add(Me.lblFees)
        Me.Panel1.Controls.Add(Me.cmbRoomOcupancy)
        Me.Panel1.Controls.Add(Me.cmbRoomType)
        Me.Panel1.Controls.Add(Me.cmbFirstName)
        Me.Panel1.Controls.Add(Me.txtMobileno)
        Me.Panel1.Controls.Add(Me.lblmobileno)
        Me.Panel1.Controls.Add(Me.lblpincode)
        Me.Panel1.Controls.Add(Me.txtfees)
        Me.Panel1.Controls.Add(Me.lblRoomType)
        Me.Panel1.Controls.Add(Me.DateTimePickerOUT)
        Me.Panel1.Controls.Add(Me.lblCheckOut)
        Me.Panel1.Controls.Add(Me.DateTimePickerIN)
        Me.Panel1.Controls.Add(Me.lblChechIN)
        Me.Panel1.Controls.Add(Me.txtRegisterID)
        Me.Panel1.Controls.Add(Me.lblRegisterID)
        Me.Panel1.Controls.Add(Me.txtRoomID)
        Me.Panel1.Controls.Add(Me.lblRoomId)
        Me.Panel1.Controls.Add(Me.txtEmailid)
        Me.Panel1.Controls.Add(Me.lblStdEmailId)
        Me.Panel1.Controls.Add(Me.txtRoomBlock)
        Me.Panel1.Controls.Add(Me.lblRoomBlock)
        Me.Panel1.Controls.Add(Me.lblFname)
        Me.Panel1.Location = New System.Drawing.Point(12, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(817, 722)
        Me.Panel1.TabIndex = 0
        '
        'txtTotalfees
        '
        Me.txtTotalfees.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtTotalfees.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtTotalfees.Enabled = False
        Me.txtTotalfees.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalfees.ForeColor = System.Drawing.Color.Black
        Me.txtTotalfees.Location = New System.Drawing.Point(181, 177)
        Me.txtTotalfees.Name = "txtTotalfees"
        Me.txtTotalfees.Size = New System.Drawing.Size(207, 22)
        Me.txtTotalfees.TabIndex = 73
        '
        'lblTotalfees
        '
        Me.lblTotalfees.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblTotalfees.AutoSize = True
        Me.lblTotalfees.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblTotalfees.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalfees.ForeColor = System.Drawing.Color.White
        Me.lblTotalfees.Location = New System.Drawing.Point(50, 180)
        Me.lblTotalfees.Name = "lblTotalfees"
        Me.lblTotalfees.Size = New System.Drawing.Size(100, 16)
        Me.lblTotalfees.TabIndex = 74
        Me.lblTotalfees.Text = "TOTAL FEES"
        '
        'btnREset
        '
        Me.btnREset.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnREset.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnREset.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnREset.ForeColor = System.Drawing.Color.Black
        Me.btnREset.Location = New System.Drawing.Point(332, 604)
        Me.btnREset.Name = "btnREset"
        Me.btnREset.Size = New System.Drawing.Size(160, 70)
        Me.btnREset.TabIndex = 42
        Me.btnREset.Text = "RESET"
        Me.btnREset.UseVisualStyleBackColor = False
        '
        'DataGridViewAddRoom
        '
        Me.DataGridViewAddRoom.BackgroundColor = System.Drawing.Color.Gainsboro
        Me.DataGridViewAddRoom.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewAddRoom.Location = New System.Drawing.Point(18, 374)
        Me.DataGridViewAddRoom.Name = "DataGridViewAddRoom"
        Me.DataGridViewAddRoom.Size = New System.Drawing.Size(783, 196)
        Me.DataGridViewAddRoom.TabIndex = 72
        '
        'btnBack
        '
        Me.btnBack.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnBack.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.ForeColor = System.Drawing.Color.Black
        Me.btnBack.Location = New System.Drawing.Point(564, 604)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(160, 70)
        Me.btnBack.TabIndex = 43
        Me.btnBack.Text = "BACK"
        Me.btnBack.UseVisualStyleBackColor = False
        '
        'txtDetails
        '
        Me.txtDetails.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtDetails.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtDetails.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDetails.ForeColor = System.Drawing.Color.Black
        Me.txtDetails.Location = New System.Drawing.Point(579, 134)
        Me.txtDetails.Name = "txtDetails"
        Me.txtDetails.Size = New System.Drawing.Size(207, 22)
        Me.txtDetails.TabIndex = 70
        '
        'btnAdd
        '
        Me.btnAdd.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd.ForeColor = System.Drawing.Color.Black
        Me.btnAdd.Location = New System.Drawing.Point(98, 604)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(160, 70)
        Me.btnAdd.TabIndex = 41
        Me.btnAdd.Text = "BOOK ROOM"
        Me.btnAdd.UseVisualStyleBackColor = False
        '
        'lblRoomDetails
        '
        Me.lblRoomDetails.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblRoomDetails.AutoSize = True
        Me.lblRoomDetails.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblRoomDetails.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRoomDetails.ForeColor = System.Drawing.Color.White
        Me.lblRoomDetails.Location = New System.Drawing.Point(448, 137)
        Me.lblRoomDetails.Name = "lblRoomDetails"
        Me.lblRoomDetails.Size = New System.Drawing.Size(71, 16)
        Me.lblRoomDetails.TabIndex = 71
        Me.lblRoomDetails.Text = "DETAILS"
        '
        'lblFees
        '
        Me.lblFees.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblFees.AutoSize = True
        Me.lblFees.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblFees.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFees.ForeColor = System.Drawing.Color.White
        Me.lblFees.Location = New System.Drawing.Point(74, 137)
        Me.lblFees.Name = "lblFees"
        Me.lblFees.Size = New System.Drawing.Size(47, 16)
        Me.lblFees.TabIndex = 69
        Me.lblFees.Text = "FEES"
        '
        'cmbRoomOcupancy
        '
        Me.cmbRoomOcupancy.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.cmbRoomOcupancy.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.cmbRoomOcupancy.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbRoomOcupancy.ForeColor = System.Drawing.Color.Black
        Me.cmbRoomOcupancy.FormattingEnabled = True
        Me.cmbRoomOcupancy.Items.AddRange(New Object() {"SOLO-1", "DUO-2", "TRIPLE-3", "QUATRA-4"})
        Me.cmbRoomOcupancy.Location = New System.Drawing.Point(579, 83)
        Me.cmbRoomOcupancy.Name = "cmbRoomOcupancy"
        Me.cmbRoomOcupancy.Size = New System.Drawing.Size(207, 24)
        Me.cmbRoomOcupancy.TabIndex = 68
        '
        'cmbRoomType
        '
        Me.cmbRoomType.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.cmbRoomType.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.cmbRoomType.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbRoomType.ForeColor = System.Drawing.Color.Black
        Me.cmbRoomType.FormattingEnabled = True
        Me.cmbRoomType.Items.AddRange(New Object() {"AC", "NON-AC", "OTHER"})
        Me.cmbRoomType.Location = New System.Drawing.Point(181, 86)
        Me.cmbRoomType.Name = "cmbRoomType"
        Me.cmbRoomType.Size = New System.Drawing.Size(207, 24)
        Me.cmbRoomType.TabIndex = 67
        '
        'cmbFirstName
        '
        Me.cmbFirstName.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.cmbFirstName.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.cmbFirstName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbFirstName.ForeColor = System.Drawing.Color.Black
        Me.cmbFirstName.FormattingEnabled = True
        Me.cmbFirstName.Location = New System.Drawing.Point(182, 323)
        Me.cmbFirstName.Name = "cmbFirstName"
        Me.cmbFirstName.Size = New System.Drawing.Size(207, 24)
        Me.cmbFirstName.TabIndex = 66
        '
        'txtMobileno
        '
        Me.txtMobileno.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtMobileno.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtMobileno.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMobileno.ForeColor = System.Drawing.Color.Black
        Me.txtMobileno.Location = New System.Drawing.Point(586, 317)
        Me.txtMobileno.Name = "txtMobileno"
        Me.txtMobileno.Size = New System.Drawing.Size(207, 22)
        Me.txtMobileno.TabIndex = 63
        '
        'lblmobileno
        '
        Me.lblmobileno.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblmobileno.AutoSize = True
        Me.lblmobileno.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblmobileno.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmobileno.ForeColor = System.Drawing.Color.White
        Me.lblmobileno.Location = New System.Drawing.Point(418, 323)
        Me.lblmobileno.Name = "lblmobileno"
        Me.lblmobileno.Size = New System.Drawing.Size(132, 16)
        Me.lblmobileno.TabIndex = 65
        Me.lblmobileno.Text = "MOBILE NUMBER"
        '
        'lblpincode
        '
        Me.lblpincode.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblpincode.AutoSize = True
        Me.lblpincode.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblpincode.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpincode.ForeColor = System.Drawing.Color.White
        Me.lblpincode.Location = New System.Drawing.Point(419, 86)
        Me.lblpincode.Name = "lblpincode"
        Me.lblpincode.Size = New System.Drawing.Size(150, 16)
        Me.lblpincode.TabIndex = 64
        Me.lblpincode.Text = "ROOM OCCUPANCY"
        '
        'txtfees
        '
        Me.txtfees.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtfees.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtfees.Enabled = False
        Me.txtfees.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtfees.ForeColor = System.Drawing.Color.Black
        Me.txtfees.Location = New System.Drawing.Point(182, 134)
        Me.txtfees.Name = "txtfees"
        Me.txtfees.Size = New System.Drawing.Size(207, 22)
        Me.txtfees.TabIndex = 60
        '
        'lblRoomType
        '
        Me.lblRoomType.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblRoomType.AutoSize = True
        Me.lblRoomType.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblRoomType.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRoomType.ForeColor = System.Drawing.Color.White
        Me.lblRoomType.Location = New System.Drawing.Point(69, 89)
        Me.lblRoomType.Name = "lblRoomType"
        Me.lblRoomType.Size = New System.Drawing.Size(97, 16)
        Me.lblRoomType.TabIndex = 62
        Me.lblRoomType.Text = "ROOM TYPE"
        '
        'DateTimePickerOUT
        '
        Me.DateTimePickerOUT.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.DateTimePickerOUT.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateTimePickerOUT.Location = New System.Drawing.Point(588, 215)
        Me.DateTimePickerOUT.Name = "DateTimePickerOUT"
        Me.DateTimePickerOUT.Size = New System.Drawing.Size(169, 22)
        Me.DateTimePickerOUT.TabIndex = 58
        '
        'lblCheckOut
        '
        Me.lblCheckOut.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblCheckOut.AutoSize = True
        Me.lblCheckOut.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblCheckOut.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCheckOut.ForeColor = System.Drawing.Color.White
        Me.lblCheckOut.Location = New System.Drawing.Point(450, 220)
        Me.lblCheckOut.Name = "lblCheckOut"
        Me.lblCheckOut.Size = New System.Drawing.Size(95, 16)
        Me.lblCheckOut.TabIndex = 59
        Me.lblCheckOut.Text = "CHECK-OUT"
        '
        'DateTimePickerIN
        '
        Me.DateTimePickerIN.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.DateTimePickerIN.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateTimePickerIN.Location = New System.Drawing.Point(181, 221)
        Me.DateTimePickerIN.Name = "DateTimePickerIN"
        Me.DateTimePickerIN.Size = New System.Drawing.Size(206, 22)
        Me.DateTimePickerIN.TabIndex = 53
        '
        'lblChechIN
        '
        Me.lblChechIN.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblChechIN.AutoSize = True
        Me.lblChechIN.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblChechIN.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblChechIN.ForeColor = System.Drawing.Color.White
        Me.lblChechIN.Location = New System.Drawing.Point(65, 227)
        Me.lblChechIN.Name = "lblChechIN"
        Me.lblChechIN.Size = New System.Drawing.Size(78, 16)
        Me.lblChechIN.TabIndex = 57
        Me.lblChechIN.Text = "CHECK-IN"
        '
        'txtRegisterID
        '
        Me.txtRegisterID.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtRegisterID.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtRegisterID.Enabled = False
        Me.txtRegisterID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRegisterID.ForeColor = System.Drawing.Color.Black
        Me.txtRegisterID.Location = New System.Drawing.Point(185, 273)
        Me.txtRegisterID.Name = "txtRegisterID"
        Me.txtRegisterID.Size = New System.Drawing.Size(203, 22)
        Me.txtRegisterID.TabIndex = 43
        '
        'lblRegisterID
        '
        Me.lblRegisterID.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblRegisterID.AutoSize = True
        Me.lblRegisterID.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblRegisterID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRegisterID.ForeColor = System.Drawing.Color.White
        Me.lblRegisterID.Location = New System.Drawing.Point(27, 279)
        Me.lblRegisterID.Name = "lblRegisterID"
        Me.lblRegisterID.Size = New System.Drawing.Size(140, 16)
        Me.lblRegisterID.TabIndex = 55
        Me.lblRegisterID.Text = "REGISTRATION ID"
        '
        'txtRoomID
        '
        Me.txtRoomID.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtRoomID.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtRoomID.Enabled = False
        Me.txtRoomID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRoomID.ForeColor = System.Drawing.Color.Black
        Me.txtRoomID.Location = New System.Drawing.Point(181, 35)
        Me.txtRoomID.Name = "txtRoomID"
        Me.txtRoomID.Size = New System.Drawing.Size(207, 22)
        Me.txtRoomID.TabIndex = 46
        '
        'lblRoomId
        '
        Me.lblRoomId.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblRoomId.AutoSize = True
        Me.lblRoomId.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblRoomId.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRoomId.ForeColor = System.Drawing.Color.White
        Me.lblRoomId.Location = New System.Drawing.Point(74, 41)
        Me.lblRoomId.Name = "lblRoomId"
        Me.lblRoomId.Size = New System.Drawing.Size(72, 16)
        Me.lblRoomId.TabIndex = 54
        Me.lblRoomId.Text = "ROOM ID"
        '
        'txtEmailid
        '
        Me.txtEmailid.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtEmailid.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtEmailid.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmailid.ForeColor = System.Drawing.Color.Black
        Me.txtEmailid.Location = New System.Drawing.Point(586, 273)
        Me.txtEmailid.Name = "txtEmailid"
        Me.txtEmailid.Size = New System.Drawing.Size(207, 22)
        Me.txtEmailid.TabIndex = 51
        '
        'lblStdEmailId
        '
        Me.lblStdEmailId.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblStdEmailId.AutoSize = True
        Me.lblStdEmailId.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblStdEmailId.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStdEmailId.ForeColor = System.Drawing.Color.White
        Me.lblStdEmailId.Location = New System.Drawing.Point(474, 279)
        Me.lblStdEmailId.Name = "lblStdEmailId"
        Me.lblStdEmailId.Size = New System.Drawing.Size(71, 16)
        Me.lblStdEmailId.TabIndex = 52
        Me.lblStdEmailId.Text = "EMAIL ID"
        '
        'txtRoomBlock
        '
        Me.txtRoomBlock.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtRoomBlock.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtRoomBlock.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRoomBlock.ForeColor = System.Drawing.Color.Black
        Me.txtRoomBlock.Location = New System.Drawing.Point(579, 38)
        Me.txtRoomBlock.Name = "txtRoomBlock"
        Me.txtRoomBlock.Size = New System.Drawing.Size(207, 22)
        Me.txtRoomBlock.TabIndex = 48
        '
        'lblRoomBlock
        '
        Me.lblRoomBlock.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblRoomBlock.AutoSize = True
        Me.lblRoomBlock.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblRoomBlock.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRoomBlock.ForeColor = System.Drawing.Color.White
        Me.lblRoomBlock.Location = New System.Drawing.Point(430, 41)
        Me.lblRoomBlock.Name = "lblRoomBlock"
        Me.lblRoomBlock.Size = New System.Drawing.Size(105, 16)
        Me.lblRoomBlock.TabIndex = 49
        Me.lblRoomBlock.Text = "ROOM BLOCK"
        '
        'lblFname
        '
        Me.lblFname.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblFname.AutoSize = True
        Me.lblFname.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblFname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFname.ForeColor = System.Drawing.Color.White
        Me.lblFname.Location = New System.Drawing.Point(68, 327)
        Me.lblFname.Name = "lblFname"
        Me.lblFname.Size = New System.Drawing.Size(99, 16)
        Me.lblFname.TabIndex = 47
        Me.lblFname.Text = "FIRST NAME"
        '
        'AddRooms
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.BackgroundImage = Global.HMS.My.Resources.Resources.Hostel_Wallpaper_Background
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(841, 746)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "AddRooms"
        Me.Text = "AddRooms"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.DataGridViewAddRoom, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents cmbFirstName As System.Windows.Forms.ComboBox
    Friend WithEvents txtMobileno As System.Windows.Forms.TextBox
    Friend WithEvents lblmobileno As System.Windows.Forms.Label
    Friend WithEvents lblpincode As System.Windows.Forms.Label
    Friend WithEvents txtfees As System.Windows.Forms.TextBox
    Friend WithEvents lblRoomType As System.Windows.Forms.Label
    Friend WithEvents DateTimePickerOUT As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblCheckOut As System.Windows.Forms.Label
    Friend WithEvents DateTimePickerIN As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblChechIN As System.Windows.Forms.Label
    Friend WithEvents txtRegisterID As System.Windows.Forms.TextBox
    Friend WithEvents lblRegisterID As System.Windows.Forms.Label
    Friend WithEvents txtRoomID As System.Windows.Forms.TextBox
    Friend WithEvents lblRoomId As System.Windows.Forms.Label
    Friend WithEvents txtEmailid As System.Windows.Forms.TextBox
    Friend WithEvents lblStdEmailId As System.Windows.Forms.Label
    Friend WithEvents txtRoomBlock As System.Windows.Forms.TextBox
    Friend WithEvents lblRoomBlock As System.Windows.Forms.Label
    Friend WithEvents lblFname As System.Windows.Forms.Label
    Friend WithEvents lblFees As System.Windows.Forms.Label
    Friend WithEvents cmbRoomOcupancy As System.Windows.Forms.ComboBox
    Friend WithEvents cmbRoomType As System.Windows.Forms.ComboBox
    Friend WithEvents txtDetails As System.Windows.Forms.TextBox
    Friend WithEvents lblRoomDetails As System.Windows.Forms.Label
    Friend WithEvents DataGridViewAddRoom As System.Windows.Forms.DataGridView
    Friend WithEvents btnREset As System.Windows.Forms.Button
    Friend WithEvents btnBack As System.Windows.Forms.Button
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents txtTotalfees As System.Windows.Forms.TextBox
    Friend WithEvents lblTotalfees As System.Windows.Forms.Label
End Class
